@include('frontend.layouts-frontend.header')

<main>
    @yield('content')
</main>

@include('frontend.layouts-frontend.footer')