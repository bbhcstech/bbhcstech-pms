<?php

namespace Maatwebsite\Excel\Concerns;

interface SkipsEmptyRows
{
}
