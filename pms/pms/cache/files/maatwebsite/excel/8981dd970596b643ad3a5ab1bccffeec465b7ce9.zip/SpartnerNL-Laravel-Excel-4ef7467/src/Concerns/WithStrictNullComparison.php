<?php

namespace Maatwebsite\Excel\Concerns;

interface WithStrictNullComparison
{
}
